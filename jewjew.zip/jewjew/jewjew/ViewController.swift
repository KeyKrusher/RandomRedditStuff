//
//  ViewController.swift
//  jewjew
//
//  Created by period2 on 4/20/17.
//  Copyright © 2017 Chubs Clark. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var puppyImageView: UIImageView!
    
    @IBAction func puppyButton(_ sender: UIButton) {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

